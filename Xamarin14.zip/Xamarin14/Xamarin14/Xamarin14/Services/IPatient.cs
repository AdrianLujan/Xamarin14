﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xamarin14.Services
{
    class IPatient
    {
    }
}
